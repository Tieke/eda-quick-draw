  create-cluster
     --ami-version <value>
     --instance-type <value> | --instance-groups <value>
     --instance-count <value>
     [--auto-terminate | --no-auto-terminate]
     [--use-default-roles]
     [--service-role <value>]
     [--name <value>]
     [--log-uri <value>]
     [--additional-info <value>]
     [--ec2-attributes <value>]
     [--termination-protected | --no-termination-protected]
     [--visible-to-all-users | --no-visible-to-all-users]
     [--enable-debugging | --no-enable-debugging]
     [--tags <value>]
     [--applications <value>]
     [--emrfs <value>]
     [--bootstrap-actions <value>]
     [--steps <value>]
     [--restore-from-hbase-backup <value>]
