**To get information about a health check**

The following ``get-health-check`` command gets information about the health check that has a ``health-check-id`` of ``02ec8401-9879-4259-91fa-04e66d094674``::

  aws route53 get-health-check --health-check-id 02ec8401-9879-4259-91fa-04e66d094674

